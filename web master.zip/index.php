<?php 

    include_once 'inc/header.php';

?>
    <div id="papel" class="papel">
        <h1 class='atrevete'>
            <div class="atrevetetxt">
                <!-- <div class="yinyang"></div> -->
                <p>ATREVETE A SENTIRTE SEGURO</p> 
            </div>

            <div class="atrevetetxt2">
                <p>
                
                Kenpo es una combinación de 
                antiguas técnicas de 
                pelea y principios científicos modernos, un 
                flujo de movimientos sin fin, una fuerza que
                 puede aplastar a cualquier atacante. 
                 Cada movimiento genera una reacción 
                 específica en el oponente, y cada 
                 reacción te guía a tu próximo movimiento. 
                 Cada golpe es un bloqueo y cada bloqueo es 
                 un golpe. Cada movimiento fluye hacia el siguiente, 
                 esta secuencia lógica de flujo y acción es la esencia del kenpo.
                </p>
                <div id='botonatrevete' class="botonatrevete"> 
                    <img class="yingyan" src="img/yang.png" alt="ying yan">
                    <div class="flecha"></div>
                </div>
                <p class="atrevetetxtnone">
                
                Kenpo es una combinación de 
                antiguas técnicas de 
                pelea y principios científicos modernos, un 
                flujo de movimientos sin fin, una fuerza que
                 puede aplastar a cualquier atacante. 
                 Cada movimiento genera una reacción 
                 específica en el oponente, y cada 
                 reacción te guía a tu próximo movimiento. 
                 Cada golpe es un bloqueo y cada bloqueo es 
                 un golpe. Cada movimiento fluye hacia el siguiente, 
                 esta secuencia lógica de flujo y acción es la esencia del kenpo.
                </p>

            </div>

          
        </h1>
    </div>
  


    <div id="atrevetedescripcion" class="atrevetedescripcion">
        <div id='atrevetedescripcion2' class="atrevetedescripcion2">
        <!-- <p>  
            El kenpo es un arte marcial que usa la ciencia y la evolucion como base para adaptarse
            a con el pasar del tiempo, EL practicante de kenpo evoluciona con el tiempo y un maestro de kenpo 
            pasa a ser el maestro de si mismo, porque un practicante del kenpo siempre esta buscando la manera
            de mejorar su tecnica y sus abilidades, por medio del estudio, la practica y la meditacion.
         </p> -->
         <p>
            El American Kenpo Karate es un 
            arte marcial y sistema de autodefensa
             moderno creado por el maestro Edmund Parker
              en Honolulu, Hawái, Estados Unidos.
               Durante los años 50, Parker estudió 
               las artes marciales japonesas del Karate, 
               el Judo, y el Jiu-jitsu tradicional además
                del Kung Fu dándose cuenta de que los diferentes
                 movimientos están basados en principios y conceptos
                  comunes de defensa y ataque.
              
         
         </p>
         
         <img src="img/karate.png" alt="Kenpoista">
        </div>

        <div class="ralla"></div>
        
        
        <div class="atrevetedescripcion2"> 
              
           
            <p>  En la asociacion Perozo American Kenpo Evolution   practicamos el kenpo y lo llevamos a otro nivel, nos mantenemos actualizados cientifica y culturalmente.
                
                <br>
                <br>
                <br>
                Entranamos en un abiente agradable y la practica te permitira desarrollar diversas abilidades fisicas, mentales, mejor persepcion de tu entorno, velosidad, 
                reflejos, potencia y por ultimo pero no menos importante <span>VERDADERA EFICIENCIA Y SEGURIDAD AL DEFENDERTE.</span></p>
            
            <div class="vid1">

            <iframe  src="https://www.youtube.com/embed/6AQobDtlOGs" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay;                   clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>
        </div>
        
            
        <div class="atrevetedescripcionmas">
            <a  href="tecnicas.php">  VER MAS</a>

        </div>
    </div>
    
    <div id="degradado" class="degradado">

    </div>
    <div id="infoMasterContenedor" class='infoMasterContenedor'>
        <h2 class='tituloInfoMaster'>Master Romer Perozo</h2>
        <div class='infoMasterContenedor2'>

        
            <div class='imgMasterInfoMaster'>
                <img src="img/MasterInfo3.jpg" alt="Master">
            </div>

            <div class='infoMasterContenedorDatos'>

                <div class='infoMasterContenedorTexto'>
                    

                    <p class='infoMasterContenedorTexto'>
                        Lorem ipsum dolor, sit amet consectetur adipisicing elit. Enim consequatur repellendus odit similique minus earum blanditiis, ut unde illo, modi pariatur sint quis exercitationem veritatis distinctio odio sunt nostrum ipsum.
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eius molestias quam laborum numquam debitis, rerum totam, ad exercitationem obcaecati ab sapiente a vel repudiandae at? Perferendis inventore facilis repudiandae maiores.
                      </p>
                </div>

                
                <div style='display:block; '>


                <div class='cinturon'>
                    <img class='imgCircular' src="img/6dan.png" alt="">
                    <p>Cinturon Negro Sexto Dan en Kenpo Karate </p>
                </div>
            </div>
                
            <div class='infoMasterContenedorRedes'>
                <a target="_blank" class="redesMasterInfo faceboock" href="https://www.facebook.com/PEROZOAMERICANKENPOEVOLUTION" ><i class="fab fa-facebook" > </i> <samp>Facebook</samp> </a>
                <a target="_blank" class="redesMasterInfo instagram" href="https://www.instagram.com/masterperozo/"><i class="fab fa-instagram-square"></i> <samp>Instagram</samp> </a>
                <a  class="redesMasterInfo mensaje" href="contactos.php"><i class="fas fa-envelope"></i> <samp>Mensaje</samp> </a>
                


            </div>
            </div>

          
        
        </div>
        
            
                    
                    

        </div>



    </div>



    <div class="presentacion">

        <div class="info">
            <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Temporibus, illum molestiae.Temporibus, illum molestiae.Temporibus, illum molestiae.Temporibus, illum molestiae.Temporibus, illum molestiae.

            </p>
            <div class='redesMaster'>
                <a class="botonMasInfo" href="contactos.php">Mas informacion</a>

            </div>
           
        </div>

        <img src="img/logo.jpg" alt="master">
        
        
    </div>


    


    <div class='preguntas contenedor'>

       <ul>
        <li>
            <div id='pregunta1' class='btnpregunta'>
                <h2>Por que entrenar artes marciales?</h2>
                <i class="fas fa-chevron-down"></i>
            </div>
            <p id='respuesta1' class="respuesta" style='display:none;'>
            Entrenar artes marciales tiene una gran variedad de beneficios, entre los que están:
            <br>
            El poder defenderte por ti mismo o ti misma.
            <br>
            Al entrenar también haces ejercicio lo que afecta directamente en tu condición y salud
            física, haces ejercicio cardiovascular, aerobicos , anaerobicos, fuerza, velocidad, flexibilidad y un uso bastante completo de los músculos y articulaciones.
            <br>
            Permite liberar estrés y dar auto control al que lo practica, permitiendo tener mas confianza, madures mental y disciplina.
            </p>
        </li>
        <li>
            <div id='pregunta2' class='btnpregunta'>
                <h2 >que arte marcial deberia practicar?</h2>
                <i class="fas fa-chevron-down"></i>
            </div>
            <p id='respuesta2' class="respuesta" style='display:none;'>
            Existen gran variedad de artes marciales en todo el mundo, cada una tiene sus pros y contras pero para saber que arte marcial quieres practicar tienes que saber que es lo que quieres conseguir y en base a eso elegir entre el karate, kenpo, twondon, kung-fu, jiu jitsu , etc.
            <br>
            
            </p>
        </li>

       

        <li>
            <div id='pregunta3' class='btnpregunta'>
                <h2>Que necesito para entrenar?</h2>
                <i class="fas fa-chevron-down"></i>
            </div>
            <p id='respuesta3' class="respuesta" style='display:none;'>
            Para comenzar a entrenar es preferible tener mas de 6 años de edad y las suficiente ganas de aprender busca una academia y dependiendo de la misma varían los requerimiento. <br>
            En la asociación puando solo necesitas la inscripción y puedes comenzar de una ves, después de eso te puedes ir comprando los implemento y el resto del equipo con el pasar del tiempo.
            </p>
        </li>
        <li>
            <div id='pregunta4' class='btnpregunta'>
                <h2>Por que Kenpo?</h2>
                <i class="fas fa-chevron-down"></i>
            </div>
            <p  id='respuesta4' class="respuesta" style='display:none;'>
            El kenpo es un arte marcial muy completo que utiliza principios científicos modernos aplicados a artes marciales tradicionales. es muy bueno para la defensa personal y posee una variedad con mas de 157  técnicas de defensa personal.
            </p>
        </li>

        <li>
            <div id='pregunta5' class='btnpregunta'>
                <h2>El kenpo funciona?</h2>
                <i class="fas fa-chevron-down"></i>
            </div>
            <p id='respuesta5' class="respuesta" style='display:none;'>
            El kenpo funciona y lo hace por que usa principios científicos y el estudio minucioso de cada técnicas para evolucionar constantemente y adaptarse a l combate  y armas modernas, tanto de otras artes marciales como la defensa personal en la calle.
            </p>
        </li>
       
       
       
       </ul>




    </div>

    <div class='nivelesContenedor'>
        <div class='contenedorNivelesMaster'>
            
            <div class='nivelCont'>
                <img src="img/k1.jpg" alt="">
                <p>Si tienes entre 6 y 12 años puedes entrenar en la clase para niños </p>
            </div>
            <div class='nivelCont'>
                <img src="img/k2.jpg" alt="">
                <p>Si tienes entre 12 y 18 años puedes entrenar en la clase para niños </p>
            </div>
            <div class='nivelCont'>
                <img src="img/k3.png" alt="">
                <p>Y si eres mayor de edad esta la clases para adultos y avanzados </p>
            </div>
            
                
           
            
        </div>
        
        <img class="drack" src="img/drack.png" alt="">
       
    </div>

    








<?php

    include_once 'inc/footer.php';


?>