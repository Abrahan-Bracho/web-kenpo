<?php 

    include_once 'inc/header.php';

?>


<div class='contenedorImagenes'>
      
    <div class="vid1">
        <iframe  src="https://www.youtube.com/embed/6AQobDtlOGs" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay;                   clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
    </div>
    <img class='imagenGaleria img1' src="img/fotos/1.jpg" alt="primera imagen">
    <img class='imagenGaleria img2' src="img/fotos/2.jpg" alt="segunda imagen">
    <img class='imagenGaleria img3' src="img/fotos/3.jpg" alt=" tercera imagen">
    <img class='imagenGaleria img4' src="img/fotos/4.jpg" alt="cuarta imagen">
    <img class='imagenGaleria img5' src="img/fotos/5.jpg" alt="quinta imagen">
    <img class='imagenGaleria img6' src="img/fotos/6.jpg" alt="quinta imagen">
    <img class='imagenGaleria img7' src="img/fotos/7.jpg" alt="quinta imagen">
    <img class='imagenGaleria img8' src="img/fotos/8.jpg" alt="quinta imagen">
    <img class='imagenGaleria img9' src="img/fotos/9.jpg" alt="quinta imagen">
    <img class='imagenGaleria img10' src="img/fotos/10.jpg" alt="quinta imagen">
    <div class='contenedor-img-galeria'>
        <img src="" alt="" class='img_ver'>
        <i class="far fa-times-circle"></i>
    </div>

</div>






<?php 

    include_once 'inc/footer.php';

?>