<?php 

    include_once 'inc/header.php';

?>

<p class="tituloInfoMaster">Redes y contactos </p>


<div class='contactos'>

    
    <img class='imgasociacion' src="img/logo.jpg" alt="">
 
    <div class='datosdecontacto'>
        <div>
            <p>Si estas interesado en entrenar o en unirte a nuestra asociacion, puedes enviar un mesaje a cualquiera de las redes y telefonosque aparesen aqui.</p>
        </div>
        <div class='infocontac'>
            <a target="_blank" class="redesMasterInfo faceboock" href="https://www.facebook.com/PEROZOAMERICANKENPOEVOLUTION"><i class="fab fa-facebook"></i> <samp>Facebook</samp> </a>
            <a target="_blank" class="redesMasterInfo instagram" href="https://www.instagram.com/masterperozo/"><i class="fab fa-instagram-square"></i> <samp>Instagram</samp> </a>
            <p class='organisacioncorreo'> Telefono: <samp>master@hotmail.com</samp> </p>
            <p class='organisaciontelefono'>Telefono: <samp>04141655695</samp> </p>    

        </div>
        
    </div>

</div>



<?php 

    include_once 'inc/footer.php';

?>