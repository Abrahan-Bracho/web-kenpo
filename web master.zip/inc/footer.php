

<div class='footer'>

    <div class='footerText'>
        <p>Perozo American Kenpo Evolution.</p>
        <samp>Esta pagina esta echa para la Organisacion internacional Perozo american kenpo evolution, su contenido e informacion pertenece a la misma y en caso de querer mas informacion contactar con el representante o el desarrollador.</samp>
    </div>

    <div class='footerCont'>
        
        <div class='rf1'>

            <a href="index.php"><img src="img/apple-touch-icon.png" alt=""></a>
            <div class='redesFooter'>
                
                <a target="_blank" class="redesMasterInfo faceboock" href="https://www.facebook.com/PEROZOAMERICANKENPOEVOLUTION"><i class="fab fa-facebook"></i> <samp>Facebook</samp> </a>
                <a target="_blank" class="redesMasterInfo instagram" href="https://www.instagram.com/masterperozo/"><i class="fab fa-instagram-square"></i> <samp>Instagram</samp> </a>
                <a  class="redesMasterInfo mensaje" href="contactame.php"><i class="fas fa-envelope"></i> <samp>Mensaje</samp> </a>
                
            </div>
        </div>
        
        <div class='by'>
            <p>BY:</p>
            <a href="http://abrahan-kun.rf.gd/" target="_blank" rel="noopener noreferrer">Abrahan-kun</a>
        </div>
    </div>
</div>

<script src="js/jquery-3.4.1.min.js"></script>
<script src='js/indexjs.js' ></script>
<script src='js/GSAP.js' ></script>



</body>
</html>