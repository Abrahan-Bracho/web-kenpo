<?php 

    include_once 'inc/header.php';

?>



<div id="elmapa" class="elmapa">

    <p>Elige tu pais en el mapa</p>

    <div class="titi">
        <img src="img/mundi3.png" alt="mapa">

        
        <div class=" m1 proporcionesdeencuadramiento contenedor_academi_mapa"> <spam id="peruPunto" valor="peru" class=" puntomapa" ></spam>  <p id="limaPeru">Lima, Peru</p> </div>
        
        <div class="m2 proporcionesdeencuadramiento contenedor_academi_mapa"> <spam id="venezuelapunto"  class=" puntomapa" ></spam> <p id="maracaiboVenezuela">Maracaibo, Venezuela</p>  </div>
        
        <div class="m3  proporcionesdeencuadramiento contenedor_academi_mapa"> <spam id="colombialapunto"  class=" puntomapa" ></spam> <p id="colombia">Colombia</p>  </div>
        
        <div class="m4  proporcionesdeencuadramiento contenedor_academi_mapa"> <spam id="costaricaapunto"  class=" puntomapa" ></spam> <p id="costarica">Costarica</p>  </div>
        
    

    </div>

   
   
</div>

<div class='contenedorAcademias'>
    <h2 class='titulo'>Maestros y Academias</h2>

    <div class='contenedorAcademias2'>


        <div class='academia  PeruMaestros' >
            <div class='contenedorDatosAcademia'>
                <div class='datosMaestro'>
                    <img src="img/maestros/romer.jpg" alt="Maestro">
                    <h3>Romer Perozo</h3>
                </div>
                <div class='datosAcademia'>
                    <div class='academiaInfo'>
                        <img src="img/maestros/puamdo.jpg" alt="">
                        <h2>PUAMDO</h2>
                    </div>
                    
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Fugiat alias eum labore exercitationem aut sunt ea reiciendis blanditiis, fugit tempora repellat facere dolor. Ea, iusto ad! Reiciendis sit rem quisquam.</p>
                    <div class='direccionAcademia'>
                        <img src="img/banderas/peru.png" alt="Pais">
                        Lima, Peru.
                    </div>
                </div>
            </div>
        </div>



        <div class='academia venezuelaMaestros' >
            <div class='contenedorDatosAcademia'>
                <div class='datosMaestro'>
                    <img src="img/maestros/abrahan.jpg" alt="Maestro">
                    <h3>Abrahan Bracho</h3>
                </div>
                <div class='datosAcademia'>
                    <div class='academiaInfo'>
                        <img src="img/maestros/puamdo.jpg" alt="">
                        <h2>PUAMDO</h2>
                    </div>
                    
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Fugiat alias eum labore exercitationem aut sunt ea reiciendis blanditiis, fugit tempora repellat facere dolor. Ea, iusto ad! Reiciendis sit rem quisquam.</p>
                    <div class='direccionAcademia'>
                        <img src="img/banderas/venezuela.png" alt="Pais">
                        Zuelia, Venezuela.
                    </div>
                </div>
            </div>
        </div>




       

        <div class='academia venezuelaMaestros'>
            <div class='contenedorDatosAcademia'>
                <div class='datosMaestro'>
                    <img src="img/maestros/katerine.jpg" alt="Maestro">
                    <h3>katerine Sosa</h3>
                </div>
                <div class='datosAcademia'>
                    <div class='academiaInfo'>
                        <img src="img/maestros/puamdo.jpg" alt="">
                        <h2>PUAMDO</h2>
                    </div>
                    
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Fugiat alias eum labore exercitationem aut sunt ea reiciendis blanditiis, fugit tempora repellat facere dolor. Ea, iusto ad! Reiciendis sit rem quisquam.</p>
                    <div class='direccionAcademia'>
                        <img src="img/banderas/venezuela.png" alt="Pais">
                        Zuelia, Venezuela.
                    </div>
                </div>
            </div>
        </div>



        <div class='academia colombiaMaestros'>
            <div class='contenedorDatosAcademia'>
                <div class='datosMaestro'>
                    <img src="img/maestros/x.png" alt="Maestro">
                    <h3>Anonimo</h3>
                </div>
                <div class='datosAcademia'>
                    <div class='academiaInfo'>
                        <img src="img/maestros/x.png" alt="">
                        <h2>Anonimo</h2>
                    </div>
                    
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Fugiat alias eum labore exercitationem aut sunt ea reiciendis blanditiis, fugit tempora repellat facere dolor. Ea, iusto ad! Reiciendis sit rem quisquam.</p>
                    <div class='direccionAcademia'>
                        <img src="img/banderas/colombia.png" alt="Pais">
                        Colombia.
                    </div>
                </div>
            </div>
        </div>

        
        <div class='academia costaricaMaestros'>
            <div class='contenedorDatosAcademia'>
                <div class='datosMaestro'>
                    <img src="img/maestros/x.png" alt="Maestro">
                    <h3>Anonimo</h3>
                </div>
                <div class='datosAcademia'>
                    <div class='academiaInfo'>
                        <img src="img/maestros/x.png" alt="">
                        <h2>Anonimo</h2>
                    </div>
                    
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Fugiat alias eum labore exercitationem aut sunt ea reiciendis blanditiis, fugit tempora repellat facere dolor. Ea, iusto ad! Reiciendis sit rem quisquam.</p>
                    <div class='direccionAcademia'>
                        <img src="img/banderas/costarica.png" alt="Pais">
                        Costarica.
                    </div>
                </div>
            </div>
        </div>
    </div>


</div>




<?php

    include_once 'inc/footer.php';


?>