<?php 

    include_once 'inc/header.php';

?>

<div class="contenedortecnicas">
    <img src="img/fotos/programa.jpg" class='imagenGaleria' class=" height: 40vw;" alt="">
    <div class='contenedor-img-galeria'>
        <img src="" alt="" class='img_ver'>
        <i class="far fa-times-circle"></i>
    </div>
    <div class="vid1">

    <iframe src="https://www.youtube.com/embed/222VhlX_goU" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay;                   clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
    </div>
    <div class="vid1">

    <iframe  src="https://www.youtube.com/embed/6AQobDtlOGs" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay;                   clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
    </div>
    <div class="vid1">

    <iframe  src="https://www.youtube.com/embed/LwqN9yaSFtk"  title="YouTube video player" frameborder="0" allow="accelerometer; autoplay;                   clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
    </div>
    <div class="vid1">


 


</div>







<?php 

    include_once 'inc/footer.php';

?>


